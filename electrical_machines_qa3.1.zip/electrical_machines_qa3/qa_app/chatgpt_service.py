import openai
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

class ChatGPTService:
    """Service class to interact with OpenAI ChatGPT API"""
    
    def __init__(self):
        openai.api_key = settings.OPENAI_API_KEY
    
    def get_answer(self, question_text, category="General"):
        """
        Get answer from ChatGPT for electrical machines related questions
        """
        try:
            # Create a specialized prompt for electrical machines
            prompt = f"""
            You are an expert in electrical machines and power systems. 
            Please provide a detailed, technical answer to the following question about {category} in electrical machines:
            
            Question: {question_text}
            
            Please provide:
            1. A comprehensive technical explanation
            2. Relevant formulas if applicable
            3. Practical applications
            4. Any important considerations or limitations
            
            Keep the answer focused on electrical machines and power systems.
            """
            
            response = openai.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are an expert electrical engineer specializing in electrical machines."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.7
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Error getting ChatGPT response: {str(e)}")
            # Fallback response if API fails
            return self._get_fallback_answer(question_text, category)
    
    def _get_fallback_answer(self, question_text, category):
        """Provide a fallback answer when API is not available"""
        fallback_answers = {
            'DC Machines': "DC machines are electrical devices that convert mechanical energy to DC electrical energy (generators) or vice versa (motors). They consist of a stator (field system) and rotor (armature). Key components include commutator, brushes, and field windings. The operation is based on Faraday's law of electromagnetic induction and Fleming's left/right hand rules.",
            
            'AC Machines': "AC machines include both synchronous and asynchronous (induction) machines. They operate on alternating current and are widely used in power generation and industrial applications. Key principles include rotating magnetic fields, slip in induction machines, and synchronous speed relationships.",
            
            'Transformers': "Transformers are static electrical devices that transfer electrical energy between circuits through electromagnetic induction. They work on the principle of mutual induction between primary and secondary windings. Key parameters include turns ratio, voltage regulation, efficiency, and losses (copper and iron losses).",
            
            'Induction Motors': "Induction motors are AC machines where the rotor current is induced by the stator's rotating magnetic field. They operate with slip and are classified as squirrel cage or wound rotor types. Key characteristics include starting torque, slip-speed relationship, and torque-speed curves.",
            
            'Synchronous Machines': "Synchronous machines operate at synchronous speed (Ns = 120f/P). They can function as generators or motors and have separately excited field windings. Key features include constant speed operation, power factor control capability, and synchronization requirements.",
        }
        
        return fallback_answers.get(category, 
            "This is a complex topic in electrical machines. Please consult standard textbooks on electrical machines or contact your instructor for detailed explanations. The system is currently unable to provide a comprehensive answer due to technical limitations.")

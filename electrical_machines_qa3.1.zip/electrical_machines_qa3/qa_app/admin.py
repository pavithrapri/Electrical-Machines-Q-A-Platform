
from django.contrib import admin
from .models import UserProfile, Question, Answer

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'phone_number', 'department', 'created_at']
    search_fields = ['user__username', 'user__email']
    list_filter = ['department', 'created_at']

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['title', 'user', 'category', 'created_at']
    search_fields = ['title', 'content', 'user__username']
    list_filter = ['category', 'created_at']
    readonly_fields = ['created_at']

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ['question', 'source', 'created_at']
    search_fields = ['content', 'question__title']
    list_filter = ['source', 'created_at']
    readonly_fields = ['created_at']
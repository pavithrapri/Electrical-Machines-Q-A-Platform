from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class UserProfile(models.Model):
    """Extended user profile model"""
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15, blank=True)
    department = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return f"{self.user.username}'s Profile"

class Question(models.Model):
    CATEGORY_CHOICES = [
        ('DC Machines', 'DC Machines'),
        ('Transformers', 'Transformers'),
        ('Induction Motors', 'Induction Motors'),
        ('Synchronous Machines', 'Synchronous Machines'),
        ('General', 'General'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField()
    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES, default='General')
    created_at = models.DateTimeField(default=timezone.now)
    
    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title


class Answer(models.Model):
    """Model to store AI-generated answers"""
    question = models.OneToOneField(Question, on_delete=models.CASCADE)
    content = models.TextField()
    source = models.CharField(max_length=50, default='ChatGPT')
    created_at = models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return f"Answer to: {self.question.title}"

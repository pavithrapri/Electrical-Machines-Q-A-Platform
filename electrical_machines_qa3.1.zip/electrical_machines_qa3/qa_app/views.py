from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q
from .models import Question, Answer, UserProfile
from .forms import CustomUserCreationForm, QuestionForm
from .chatgpt_service import ChatGPTService
import logging

logger = logging.getLogger(__name__)

def home(request):
    """Home page view with recent questions"""
    questions = Question.objects.all()[:10]  # Get 10 most recent questions
    context = {
        'questions': questions,
        'total_questions': Question.objects.count(),
        'total_users': UserProfile.objects.count(),
    }
    return render(request, 'home.html', context)

def register_view(request):
    """User registration view"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}! You can now login.')
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})

@login_required
def ask_question(request):
    """View for asking new questions"""
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.user = request.user
            question.save()
            
            # Get answer from ChatGPT
            try:
                chatgpt_service = ChatGPTService()
                answer_content = chatgpt_service.get_answer(
                    question.content, 
                    question.category
                )
                
                # Save the answer
                Answer.objects.create(
                    question=question,
                    content=answer_content,
                    source='ChatGPT'
                )
                
                messages.success(request, 'Your question has been submitted and answered!')
                return redirect('question_detail', question_id=question.id)
                
            except Exception as e:
                logger.error(f"Error generating answer: {str(e)}")
                messages.warning(request, 'Question saved, but answer generation failed. Please try again later.')
                return redirect('question_detail', question_id=question.id)
    else:
        form = QuestionForm()
    
    return render(request, 'ask_question.html', {'form': form})

def question_detail(request, question_id):
    """View for displaying question and its answer"""
    question = get_object_or_404(Question, id=question_id)
    try:
        answer = Answer.objects.get(question=question)
    except Answer.DoesNotExist:
        answer = None
    
    context = {
        'question': question,
        'answer': answer,
    }
    return render(request, 'question_detail.html', context)

@login_required
def profile_view(request):
    """User profile view"""
    try:
        profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)
    
    user_questions = Question.objects.filter(user=request.user)
    
    context = {
        'profile': profile,
        'user_questions': user_questions,
    }
    return render(request, 'profile.html', context)

def search_questions(request):
    """Search questions functionality"""
    query = request.GET.get('q', '')
    questions = Question.objects.all()
    
    if query:
        questions = questions.filter(
            Q(title__icontains=query) | 
            Q(content__icontains=query) |
            Q(category__icontains=query)
        )
    
    paginator = Paginator(questions, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'questions': page_obj,
        'query': query,
    }
    return render(request, 'search_results.html', context)


